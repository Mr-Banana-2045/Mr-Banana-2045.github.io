
var PROGAMS = {

  help: function(...a) {
    this.printa({
      "headers": ["command", "description"],
      "uoload ": ["Link name"],
      "clear": ["clear terminal"],
      "whoami": ["you"]
    });
  },

  upload: function(...a){
    function downloadFile(url, filename) {
    const link = document.createElement('a');;
    link.href = url;
    link.download = filename || url.split('/').pop();
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
downloadFile(a[0], a[1]);
  },
  clear: function(...a) {
    this.clear_terminal();
  },
  whoami: function(...a){
    this.printa("Sarbaz Hamas");
  }
};
